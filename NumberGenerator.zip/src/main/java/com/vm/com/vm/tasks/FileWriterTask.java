package com.vm.com.vm.tasks;

import com.vm.controllers.NumberController;
import com.vm.dto.RequestDTO;
import com.vm.entity.Tasks;
import com.vm.helper.TaskHelper;
import com.vm.repository.TaskRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;


public class FileWriterTask implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileWriterTask.class);

    private Tasks dbTask;
    private RequestDTO request;
    private TaskRepository taskRepository;

    public FileWriterTask(Tasks dbTask, RequestDTO request){
        this.dbTask = dbTask;
        this.request = request;
    }

        public void run() {
            LOGGER.info("Starting File Write Process for ID ::: "+ String.valueOf(dbTask.getId()));
            try {
                String fileName = "tmp/" + String.valueOf(dbTask.getId()) + "_output.txt";
                dbTask.setFile_name(fileName);

                new TaskHelper().writeToFile(request, fileName);
                dbTask.setStatus("SUCCESS");
            }catch (IOException | NumberFormatException e) {
                e.printStackTrace();
                LOGGER.error("File Write Error for ID ::: {}", String.valueOf(dbTask.getId()));
                dbTask.setStatus("ERROR");
            }
            dbTask = getTaskRepository().save(dbTask);
            LOGGER.info("File Write Process Completed for ID ::: "+ String.valueOf(dbTask.getId()));

        }

    public TaskRepository getTaskRepository() {
        return taskRepository;
    }

    public void setTaskRepository(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }
}
