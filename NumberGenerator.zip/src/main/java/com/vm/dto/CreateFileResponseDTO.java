package com.vm.dto;

public class CreateFileResponseDTO {
   private String task;

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }
}
