package com.vm.controllers;


import com.vm.dto.CreateFileResponseDTO;
import com.vm.dto.RequestDTO;
import com.vm.dto.ResultResponseDTO;
import com.vm.helper.TaskHelper;
import com.vm.service.NumberService;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api")
public class NumberController {

    private static final Logger LOGGER = LoggerFactory.getLogger(NumberController.class);

    @Autowired
    private NumberService numberService;

    @PostMapping(value = "generate" )
    public ResponseEntity<?> generate(@RequestBody RequestDTO request){
        try {
            CreateFileResponseDTO createFileResponseDTO = numberService.save(request);
            return new ResponseEntity(createFileResponseDTO, HttpStatus.ACCEPTED);
        }catch(Exception e){
            LOGGER.error("Error in generate numbers");
            return new ResponseEntity<>( HttpStatus.BAD_REQUEST);
        }

    }

    @GetMapping(value = "tasks/{uuid}/status")
    public ResponseEntity<?> getStatus(@PathVariable("uuid") String uuid ){
        try {
            ResultResponseDTO status = numberService.getStatus(uuid);
            if(null != status) {
                return ResponseEntity.ok(status);
            }
        }catch (Exception e){
            LOGGER.error("Error in get Status");
        }
        return new ResponseEntity<>( HttpStatus.NOT_FOUND);
    }

    @GetMapping(value = "tasks/{uuid}")
    public ResponseEntity<?> getData(@PathVariable("uuid") String uuid ,@RequestParam String action){
        if(null == action || !action.equalsIgnoreCase("get_numlist")){
            return new ResponseEntity<>( HttpStatus.BAD_REQUEST);
        }
        try {
            ResultResponseDTO data = numberService.getData(uuid, action);
            if(null  == data){
                return new ResponseEntity<>( HttpStatus.NOT_FOUND);
            }
            return ResponseEntity.ok(data);
        }catch (Exception e){
            LOGGER.error("Error in get Data");
            return new ResponseEntity<>( HttpStatus.NO_CONTENT);
        }


    }


}
