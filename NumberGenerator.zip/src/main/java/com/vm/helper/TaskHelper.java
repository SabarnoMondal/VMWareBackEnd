package com.vm.helper;

import com.vm.controllers.NumberController;
import com.vm.dto.RequestDTO;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import java.io.*;
import java.util.Scanner;

public class TaskHelper {

    private static final Logger LOGGER = LoggerFactory.getLogger(TaskHelper.class);

    public synchronized void  writeToFile(RequestDTO request, String fileName) throws IOException {


        File file = new File("tmp");
        if (!file.exists()) {
            if (file.mkdir()) {
                System.out.println("Directory is created!");
            } else {
                System.out.println("Failed to create directory!");
            }
        }
        LOGGER.info("Starting File Write for :::{}",fileName);
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        LOGGER.info("Starting number generation process for :::{}",fileName);
        String fileData = getFileData(request);
        LOGGER.info("Completed number generation process for :::{}",fileName);
        writer.write(fileData);

        writer.close();
        LOGGER.info("Completed File Write for :::{}",fileName);
    }

    private String getFileData(RequestDTO request) {
        String fileData = "";
        Long goalInput = Long.valueOf(request.getGoal());
        Long stepInput = Long.valueOf(request.getStep());
        for(Long step = goalInput ; step >= 0 ; step = step - stepInput){

            fileData = fileData + ( fileData == "" ? "": "," ) + String.valueOf(step);
            LOGGER.info("Number Generated  :::{}",step);
        }
        return fileData;

    }

    public String readFile(String fileName) throws IOException {

        StringBuilder returnData = new StringBuilder();
        try {
            File fileReader = new File(fileName);
            Scanner reader = new Scanner(fileReader);
            while (reader.hasNextLine()) {
                returnData.append(reader.nextLine());
            }
            reader.close();
        } catch (FileNotFoundException e) {
            throw e;
        }
        return returnData.toString();
    }
}
