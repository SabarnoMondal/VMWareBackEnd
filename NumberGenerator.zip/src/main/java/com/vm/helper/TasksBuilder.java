package com.vm.helper;

import com.vm.entity.Tasks;

import javax.persistence.Column;

public class TasksBuilder {

    private long id;
    private String file_name;
    private String status;

    public TasksBuilder setFile_name(String file_name) {
        this.file_name = file_name;
        return this;
    }

    public TasksBuilder setId(long task_uuid) {
        this.id = id;
        return this;
    }

    public TasksBuilder setStatus(String status) {
        this.status = status;
        return this;
    }

    public Tasks build(){
        Tasks tasks = new Tasks();
        tasks.setFile_name(this.file_name);
        tasks.setStatus(this.status);
        tasks.setId(this.id);
        return tasks;
    }
}
