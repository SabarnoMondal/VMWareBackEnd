package com.vm.service;

import com.vm.com.vm.tasks.FileWriterTask;
import com.vm.controllers.NumberController;
import com.vm.dto.CreateFileResponseDTO;
import com.vm.dto.RequestDTO;
import com.vm.dto.ResultResponseDTO;
import com.vm.entity.Tasks;
import com.vm.helper.TaskHelper;
import com.vm.helper.TasksBuilder;
import com.vm.repository.TaskRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.task.TaskExecutor;
import org.springframework.stereotype.Service;

import java.io.IOException;

@Service
public class NumberService {


    private static final Logger LOGGER = LoggerFactory.getLogger(NumberService.class);

    @Autowired
    TaskRepository taskRepository;

    @Autowired
    private TaskExecutor taskExecutor;

    private TaskHelper taskHelper;

    public CreateFileResponseDTO save(RequestDTO request) {
        LOGGER.info("Starting file Save");
        TasksBuilder inputBuilder = new TasksBuilder();
        inputBuilder.setStatus("IN_PROGRESS");


        Tasks dbTask = taskRepository.save(inputBuilder.build());


        FileWriterTask fileWriterTask = new FileWriterTask(dbTask,request);
        fileWriterTask.setTaskRepository(taskRepository);

        taskExecutor.execute(fileWriterTask);
        CreateFileResponseDTO createFileResponseDTO = new CreateFileResponseDTO();
        createFileResponseDTO.setTask(String.valueOf(dbTask.getId()));
        LOGGER.info("Starting file Completed");
        return createFileResponseDTO;
    }

    public ResultResponseDTO getStatus(String request) {
        LOGGER.info("Starting getStatus");
         Tasks status =  taskRepository.findOne(Long.valueOf(request));
         if(status != null) {
             ResultResponseDTO resultResponseDTO = new ResultResponseDTO();
             resultResponseDTO.setResult(status.getStatus());
             LOGGER.info("Completed getStatus");
             return resultResponseDTO;
         }
        LOGGER.info("Completed getStatus");
         return null;
    }

    public ResultResponseDTO getData(String uuid, String action) throws IOException {
        LOGGER.info("Started getData");
        Tasks task =  taskRepository.findOne(Long.valueOf(uuid));
        try {
            if(null == task){
                return null;
            }
            String fileData = getTaskHelper().readFile(task.getFile_name());
            ResultResponseDTO resultResponseDTO = new ResultResponseDTO();
            resultResponseDTO.setResult(fileData);
            LOGGER.info("Completed getData");
            return resultResponseDTO;
        } catch (IOException e) {
            LOGGER.info("Error in getData");
           throw e;
        }

    }

    public TaskHelper getTaskHelper() {
        if(this.taskHelper == null){
            this.taskHelper = new TaskHelper();
        }
        return this.taskHelper;
    }

    public void setTaskHelper(TaskHelper taskHelper) {
        this.taskHelper = taskHelper;
    }
}
