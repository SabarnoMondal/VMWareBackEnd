package com.vm.entity;


import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "TASKS")
@Component
public class Tasks implements Serializable {

    @Id
    @Column(name = "ID")
    @GeneratedValue
    private long id;

    @Column (name = "FILE_NAME")
    private String file_name;

    @Column (name = "STATUS")
    private String status;


    public String getFile_name() {
        return file_name;
    }

    public void setFile_name(String file_name) {
        this.file_name = file_name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
}
