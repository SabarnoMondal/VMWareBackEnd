package com.vm.service;

import com.vm.dto.CreateFileResponseDTO;
import com.vm.dto.RequestDTO;
import com.vm.dto.ResultResponseDTO;
import com.vm.entity.Tasks;
import com.vm.helper.TaskHelper;
import com.vm.repository.TaskRepository;
import com.vm.runner.JUnitControllerRunner;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.core.task.TaskExecutor;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyObject;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.*;

public class NumberServiceTest extends JUnitControllerRunner {


    @InjectMocks
    private NumberService numberService;

    @Mock
    private TaskRepository taskRepository;

    @Mock
    private TaskExecutor taskExecutor;

    @Mock
    private TaskHelper taskHelper;

    @Test
    public void testSave() throws Exception {

        Tasks tasks = new Tasks();
        tasks.setId(1);
        when(taskRepository.save(any(Tasks.class))).thenReturn(tasks);
        doNothing().when(taskExecutor).execute(any());
        RequestDTO requestDTO = new RequestDTO();

        CreateFileResponseDTO createFileResponseDTO = numberService.save(requestDTO);
        assertEquals("1",createFileResponseDTO.getTask());
    }

    @Test
    public void testGetStatus() throws Exception {

        Tasks tasks = new Tasks();
        tasks.setId(1);
        tasks.setStatus("SUCCESS");
        when(taskRepository.findOne(any(Long.class))).thenReturn(tasks);
        doNothing().when(taskExecutor).execute(any());
        RequestDTO requestDTO = new RequestDTO();

        ResultResponseDTO resultResponseDTO = numberService.getStatus("1");
        assertEquals("SUCCESS",resultResponseDTO.getResult());
    }


    @Test
    public void testGetData() throws Exception {

        Tasks tasks = new Tasks();
        tasks.setId(1);
        tasks.setStatus("SUCCESS");
        when(taskRepository.findOne(any(Long.class))).thenReturn(tasks);


        TaskHelper th = mock(TaskHelper.class);
        numberService.setTaskHelper(th);
        when(th.readFile(anyString())).thenReturn("1,2,3,4,5");


        ResultResponseDTO resultResponseDTO = numberService.getData("1","");
        assertEquals("1,2,3,4,5",resultResponseDTO.getResult());
    }
}
