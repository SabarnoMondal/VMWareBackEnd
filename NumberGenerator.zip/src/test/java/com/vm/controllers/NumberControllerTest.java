package com.vm.controllers;

import com.vm.dto.CreateFileResponseDTO;
import com.vm.dto.RequestDTO;
import com.vm.dto.ResultResponseDTO;
import com.vm.runner.JUnitControllerRunner;
import com.vm.runner.JUnitControllerRunnerMVC;
import com.vm.service.NumberService;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.when;

public class NumberControllerTest extends JUnitControllerRunnerMVC {

    @InjectMocks
    private NumberController numberController;

    @MockBean
    private NumberService numberService;

    @Test
    public void testGenerate() throws Exception {

        RequestDTO bean = new RequestDTO();
        //bean.setEnteredDate(new Date());
        bean.setGoal("5000");
        bean.setStep("2");

        CreateFileResponseDTO createFileResponseDTO = new CreateFileResponseDTO();
        when(numberService.save(bean)).thenReturn(new CreateFileResponseDTO());

        mocMvc.perform(MockMvcRequestBuilders.post("/api/generate", bean)
                .content(asJsonString(bean)).contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isAccepted());

    }


    @Test
    public void testStatus() throws Exception {

        when(numberService.getStatus("1")).thenReturn(new ResultResponseDTO());

        mocMvc.perform(MockMvcRequestBuilders.get("/api/tasks/{uuid}/status", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());

    }

    @Test
    public void testAction() throws Exception {

        when(numberService.getData(anyString(),anyString())).thenReturn(new ResultResponseDTO());

        mocMvc.perform(MockMvcRequestBuilders.get("/api/tasks/{uuid}/?action=get_numlist", 1)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isOk());

    }

}
