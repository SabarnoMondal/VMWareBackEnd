package com.vm.runner;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.vm.Application;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration
@SpringBootTest(classes = { Application.class })
public class JUnitControllerRunnerMVC {

    @Autowired
    public WebApplicationContext context;
    public MockMvc mocMvc;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        mocMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    public static String asJsonString(final Object obj) {
	    try {
	        return new ObjectMapper().writeValueAsString(obj);
	    } catch (Exception e) {
	        throw new RuntimeException(e);
	    }
	}
    
}
