import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {AngularMaterialModule} from './angular-material.module';
import {AppRoutingModule} from './app-routing.module';
import {CommonModule, DatePipe} from '@angular/common';
import { AppComponent } from './app.component';
import { HederComponent } from './heder/heder.component';
import { FooterComponent } from './footer/footer.component';
import { AngularMaterialModule } from './angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UserServiceService } from './user-service.service';
import { DataService } from './data.service';



@NgModule({
  declarations: [AppComponent , HederComponent , FooterComponent],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    CommonModule,
    AppRoutingModule,

    // MatCardModule,

    AngularMaterialModule,
    FormsModule,
    ReactiveFormsModule
    // SharedModule,
    // FontAwesomeModule,
  ],
  providers: [ DatePipe, UserServiceService, DataService],
  bootstrap: [AppComponent],
})
export class AppModule {
}
