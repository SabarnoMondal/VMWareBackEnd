import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  constructor(private http: HttpClient) { }

  validateUser(email: string, password: string ) {
   if (email === 'sabarno.mondal20@gmail.com' && password === 'password'){
     return true;
   }
   return false;
  }
}
