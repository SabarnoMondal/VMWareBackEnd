import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor() { }

  validateUser(email: string, password: string ) {
   if (email === 'sabarno.mondal20@gmail.com' && password === 'password') {
     return true;
   }
   return false;
  }
}
