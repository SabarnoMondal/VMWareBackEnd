import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserServiceService } from '../user-service.service';
import { Router } from '@angular/router';
import { UserService } from './user.service';
import { DataService } from '../data.service';
// import { DataService } from '../data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  emailId: string;
  password: string;
  emailRequired: boolean;
  emailLengthMismatch: boolean;
  passwordRequired: boolean;
  passwordLengthMismatch: boolean;
  invalidUser: boolean;
  constructor(private fb: FormBuilder, private dataService: DataService, private service: UserService , private router: Router) { }

  ngOnInit() {
    this.createAppForm();
  }

  createAppForm() {
    this.loginForm = this.fb.group({
      emailIdForm: [{ value: this.emailId, disabled: false }, Validators.compose([
        Validators.required, Validators.minLength(6)
      ])],
      passwordForm: [{ value: this.password, disabled: false }, Validators.compose([
        Validators.required, Validators.minLength(6)
      ])]
    });
  }

  login() {
    this.emailId = this.loginForm.controls['emailIdForm'].value;
    this.password = this.loginForm.controls['passwordForm'].value;
    this.emailRequired = false;
    this.emailLengthMismatch = false;
    this.passwordRequired = false;
    this.passwordLengthMismatch = false ;
    this.invalidUser = false;

    if (this.emailId === '' || this.emailId ==  null) {
      this.emailRequired = true;
    } else if (this.emailId.length < 6) {
      this.emailLengthMismatch = true;
    }

    if (this.password === '' || this.password == null) {
      this.passwordRequired = true;
    } else if (this.password.length < 6) {
      this.passwordLengthMismatch = true;
    }

    console.log(this.emailId);
    console.log(this.password);
    if (this.service.validateUser(this.emailId, this.password)) {
       this.dataService.changeId(this.emailId);
       this.router.navigate(['/home']);
    } else {
      if (!(this.emailLengthMismatch || this.emailRequired ||  this.passwordRequired || this.passwordLengthMismatch)) {
      this.invalidUser = true;
      }
    }
  }

}
