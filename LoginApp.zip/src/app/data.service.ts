import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  private emailId = new BehaviorSubject<string>('');
  currentEmailId = this.emailId.asObservable();
  constructor() { }

  changeId(id: string) {
    console.log(id);
    this.emailId.next(id);
  }
}
