import {NgModule} from '@angular/core';
// import {MatAutocompleteModule} from '@angular/material/autocomplete';
// import {MatCheckboxModule} from '@angular/material/checkbox';
// import {MatDatepickerModule} from '@angular/material/datepicker';
// import {MatFormFieldModule} from '@angular/material/form-field';
// import {MatInputModule} from '@angular/material/input';
// import {MatSelectModule} from '@angular/material/select';
// import {MatToolbarModule} from '@angular/material/toolbar';
// import {MatCardModule} from '@angular/material/card';
// import {MatDividerModule} from '@angular/material/divider';
// import {MatTabsModule} from '@angular/material/tabs';
// import {MatButtonModule} from '@angular/material/button';
// import {MatChipsModule} from '@angular/material/chips';
// import {MatStepperModule} from '@angular/material/stepper';
// import {MatIconModule} from '@angular/material/icon';
// import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
// import {MatProgressBarModule} from '@angular/material/progress-bar';
// import {MatDialogModule} from '@angular/material/dialog';
// import {MatSnackBarModule} from '@angular/material/snack-bar';
// import {MatTooltipModule} from '@angular/material/tooltip';
// import {MatPaginatorModule} from '@angular/material/paginator';

// import {MatTableModule} from '@angular/material/table';

// import {MatBadgeModule} from '@angular/material/badge';
// // import {CdkTableModule} from '@angular/cdk/table';
// import {MatTreeModule} from '@angular/material/tree';

//
// Form Controls
//



//
// Navigation
//

//
// Layout
//

//
// Buttons & Indicators
//

//
// Popups & Modals
//

//
// Data Table
//

@NgModule({
  imports: [
    // LayoutModule,
    // CdkTableModule,
    // MatAutocompleteModule,
    // MatCheckboxModule,
    // MatDatepickerModule,
    // MatFormFieldModule,
    // MatInputModule,

    // // MatRadioModule,
    // MatSelectModule,
    // // MatSliderModule,
    // // MatSlideToggleModule,
    // // MatMenuModule,
    // MatToolbarModule,
    // MatCardModule
    // MatDividerModule,
    // // MatExpansionModule,
    // // MatGridListModule,

    // // MatStepperModule,
    // MatTabsModule,
    // MatTreeModule,
    // MatButtonModule,
    // // MatButtonToggleModule,
    // MatBadgeModule,
    // MatChipsModule,
    // MatIconModule,
    // MatProgressSpinnerModule,
    // MatProgressBarModule,
    // // MatBottomSheetModule,
    // MatDialogModule,
    // MatSnackBarModule,
    // MatTooltipModule,
    // MatPaginatorModule,
    // // MatSortModule,
    // MatTableModule,
    // MatStepperModule,
  ],
  exports: [
    // CdkTableModule,
    // LayoutModule,
    // MatAutocompleteModule,
    // MatCheckboxModule,
    // MatDatepickerModule,
    // MatFormFieldModule,
    // MatInputModule,
    // // MatRadioModule,
    // MatSelectModule,
    // // MatSliderModule,
    // // MatSlideToggleModule,
    // // MatMenuModule,
    // MatToolbarModule,
    // MatCardModule
    // MatDividerModule,
    // // MatExpansionModule,
    // // MatGridListModule,
    //     // MatStepperModule,
    // MatTabsModule,
    // MatTreeModule,
    // MatButtonModule,
    // // MatButtonToggleModule,
    // MatBadgeModule,
    // MatChipsModule,
    // MatIconModule,
    // MatProgressSpinnerModule,
    // MatProgressBarModule,
    // // MatBottomSheetModule,
    // MatDialogModule,
    // MatSnackBarModule,
    // MatTooltipModule,
    // MatPaginatorModule,
    // // MatSortModule,
    // MatTableModule,
    // MatStepperModule,
  ],
})
export class AngularMaterialModule {}
